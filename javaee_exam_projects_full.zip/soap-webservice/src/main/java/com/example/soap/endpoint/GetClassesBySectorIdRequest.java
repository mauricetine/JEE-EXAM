package com.example.soap.endpoint;

public class GetClassesBySectorIdRequest {
    private Long sectorId;
    public Long getSectorId() { return sectorId; }
    public void setSectorId(Long sectorId) { this.sectorId = sectorId; }
}
